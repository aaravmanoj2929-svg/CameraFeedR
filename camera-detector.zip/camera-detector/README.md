# Camera Detector

A LAN feeder/receiver camera system. Your phone (feeder) streams video and runs
on-device pose detection to spot a person standing or moving their legs; your PC
(receiver) shows the live feed with a skeleton overlay, a status panel, and a
scrolling event log with alerts.

```
[Phone: feeder.html] --camera + pose detection--> WebRTC video --> [PC: receiver.html]
                      \--detection events (WebSocket, via server.js)--/
```

Detection (pose + a lightweight motion check) all runs **on the phone**, in the
browser, using MediaPipe. The PC never needs to touch the raw frames — it just
gets the video stream plus small JSON detection events.

## 1. Install

Open this folder in VS Code, then in its integrated terminal:

```powershell
npm install
```

## 2. Run the server (on your PC)

```powershell
node server.js
```

You'll see something like:

```
Receiver (open on PC):    http://192.168.1.42:3000/receiver.html
Feeder (open on phone):   http://192.168.1.42:3000/feeder.html
```

Your IP will differ — use whatever it prints.

**First time only — Windows Firewall:** Windows will likely pop up asking
whether to allow Node.js through the firewall. Click **Allow access**, and make
sure the **Private networks** box is checked. If you miss the prompt, search
"Allow an app through Windows Firewall" in the Start menu and add `node.exe`
manually for Private networks.

## 3. Open the receiver (on your PC)

Open `http://<your-ip>:3000/receiver.html` in a browser. It'll say
"WAITING FOR FEEDER LINK" until your phone connects.

## 4. Open the feeder (on your phone) — important gotcha

Your phone needs to be on the **same Wi-Fi network** as your PC.

Browsers only allow camera access (`getUserMedia`) on "secure contexts" —
HTTPS, or `localhost`. Your phone loading `http://192.168.x.x:3000/...` is
neither, so **the camera will be blocked by default.** You have two options:

**Option A — Chrome flag (easiest for local testing):**
1. On your phone, open Chrome and go to:
   `chrome://flags/#unsafely-treat-insecure-origin-as-secure`
2. Enable it, and in the text box that appears, add:
   `http://<your-ip>:3000` (use the exact IP the server printed)
3. Relaunch Chrome when it prompts you.
4. Now open `http://<your-ip>:3000/feeder.html` — camera access will work.

**Option B — proper HTTPS (more setup, but no flags needed):**
Use a tool like `mkcert` to generate a locally-trusted certificate, point
`server.js` at `https.createServer` instead of `http.createServer` with the
cert, and install the mkcert root CA on your phone too. Ask me if you want to
go this route — it's more robust for daily use but takes an extra ~15 minutes.

Once loaded, tap **START TRANSMISSION** and allow camera access. You should see
your phone's HUD light up and the receiver on your PC pick up the live feed
within a few seconds.

## How detection works

- **Motion**: the feeder downsamples each frame to a tiny grayscale grid and
  diffs it against the previous frame — fast, cheap, catches any movement.
- **Person / posture / leg movement**: MediaPipe's Pose Landmarker (lite model,
  runs fully on-device) tracks 33 body landmarks. From those:
  - *Standing* = hip→knee→ankle angle is close to straight, and shoulders are
    above hips above knees above ankles in the frame.
  - *Leg movement* = knee/ankle positions shift more than a small threshold
    between checks.
- An **alert** (red, triggers a toast + browser notification on the receiver)
  fires when a person is detected, standing, **and** moving their legs —
  tune the thresholds in `analyzePose()` in `feeder.html` if it's too
  sensitive or not sensitive enough for your camera angle/distance.

## Tuning tips

- `pose_landmarker_lite` is fast but less precise — if your phone can handle it,
  swap to `pose_landmarker_full` or `_heavy` in `feeder.html` (`initPose()`) for
  better accuracy at the cost of speed.
- The motion threshold (`> 6` in `checkFrameMotion()`) and leg-movement
  threshold (`> 0.035` in `analyzePose()`) are the two numbers most worth
  adjusting for your lighting/setup.
- Mount the phone somewhere stable — pose detection assumes a roughly upright,
  full-body view for the standing/leg-angle math to make sense.

## File structure

```
camera-detector/
  server.js            WebSocket signaling + detection relay + static file server
  package.json
  public/
    feeder.html         phone: camera capture, on-device detection, WebRTC sender
    receiver.html        PC: HUD dashboard, WebRTC viewer, event log, alerts
```
