const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const os = require('os');
const path = require('path');

const app = express();
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

let feeder = null;
const receivers = new Set();

function getLocalIP() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) return net.address;
    }
  }
  return 'localhost';
}

function send(ws, msg) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
}

function broadcastToReceivers(msg) {
  const data = JSON.stringify(msg);
  for (const r of receivers) {
    if (r.readyState === WebSocket.OPEN) r.send(data);
  }
}

wss.on('connection', (ws) => {
  let role = null;

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }

    switch (msg.type) {
      case 'register': {
        role = msg.role;
        if (role === 'feeder') {
          feeder = ws;
          console.log('[server] feeder connected');
          broadcastToReceivers({ type: 'feeder-status', online: true });
        } else if (role === 'receiver') {
          receivers.add(ws);
          console.log('[server] receiver connected');
          send(ws, { type: 'feeder-status', online: !!feeder });
        }
        break;
      }

      // Receiver asks the feeder to start streaming to it
      case 'request-offer': {
        send(feeder, { type: 'request-offer' });
        break;
      }

      // Feeder -> receivers
      case 'offer':
      case 'ice-candidate-feeder': {
        broadcastToReceivers(msg);
        break;
      }

      // Receiver -> feeder
      case 'answer':
      case 'ice-candidate-receiver': {
        send(feeder, msg);
        break;
      }

      // Feeder -> receivers: person/motion detection payload
      case 'detection': {
        broadcastToReceivers(msg);
        break;
      }

      default:
        break;
    }
  });

  ws.on('close', () => {
    if (role === 'feeder' && feeder === ws) {
      feeder = null;
      broadcastToReceivers({ type: 'feeder-status', online: false });
      console.log('[server] feeder disconnected');
    } else if (role === 'receiver') {
      receivers.delete(ws);
      console.log('[server] receiver disconnected');
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  const ip = getLocalIP();
  console.log('');
  console.log('=== Camera Detector Server ===');
  console.log(`Receiver (open on PC):    http://${ip}:${PORT}/receiver.html`);
  console.log(`Feeder (open on phone):   http://${ip}:${PORT}/feeder.html`);
  console.log('Phone must be on the same Wi-Fi/LAN as this PC.');
  console.log('===============================');
  console.log('');
});
